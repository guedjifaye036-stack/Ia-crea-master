IA CRÉA MASTER — version professionnelle
1. Ouvrir index.html pour tester.
2. Publier index.html sur Netlify, Vercel, GitHub Pages ou votre hébergement.
3. Le formulaire ouvre WhatsApp avec les données saisies.
4. Le paiement Wave/Orange Money est volontairement confirmé manuellement : ne publiez jamais de fausses instructions ou un tarif non confirmé.
